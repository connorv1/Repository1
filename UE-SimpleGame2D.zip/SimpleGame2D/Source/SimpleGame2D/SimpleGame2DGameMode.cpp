// Fill out your copyright notice in the Description page of Project Settings.

#include "SimpleGame2D.h"
#include "SimpleGame2DGameMode.h"




