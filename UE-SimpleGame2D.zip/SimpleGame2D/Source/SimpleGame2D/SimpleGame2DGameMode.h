// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/GameMode.h"
#include "SimpleGame2DGameMode.generated.h"

/**
 * 
 */
UCLASS()
class SIMPLEGAME2D_API ASimpleGame2DGameMode : public AGameMode
{
	GENERATED_BODY()
	
	
	
	
};
