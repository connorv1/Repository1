// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "PaperSpriteComponent.h"
#include "GameFramework/Actor.h"
#include "SimpleActor.generated.h"

UCLASS()
class SIMPLEGAME2D_API ASimpleActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ASimpleActor();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	//new code
	float RunningTime;
	float MaxMove;
	
	void ChangeShape(); //move to the next shape
	void ChangeShape(int s); //move to a specific shape
	UPaperSprite* shapes[2];
	int currentShape;
	int numShapes;

};
